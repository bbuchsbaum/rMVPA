#! /usr/bin/env Rscript

library(devtools)
install_github("rMVPA", "bbuchsbaum")
