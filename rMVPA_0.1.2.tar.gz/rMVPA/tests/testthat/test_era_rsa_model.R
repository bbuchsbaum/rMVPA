context("era_rsa_model")

test_that("era_rsa_model runs regionally and returns expected metrics", {
  skip_on_cran()
  set.seed(123)

  # Create toy encoding/retrieval dataset with external test set
  toy <- gen_sample_dataset(D = c(4,4,4), nobs = 48, nlevels = 3, blocks = 3, external_test = TRUE)

  # Add a shared item key column to both train and test designs
  toy$design$train_design$item <- toy$design$train_design$Y
  toy$design$test_design$item  <- toy$design$test_design$Ytest

  # Simple regional mask with 3 regions
  regionMask <- neuroim2::NeuroVol(sample(1:3, size = length(toy$dataset$mask), replace = TRUE),
                                   neuroim2::space(toy$dataset$mask))

  ms <- era_rsa_model(
    dataset = toy$dataset,
    design  = toy$design,
    key_var = ~ item,
    phase_var = ~ block_var,     # phase label not used in external-test path; keep for interface
    distfun = cordist("pearson"),
    rsa_simfun = "spearman"
  )

  res <- run_regional(ms, regionMask)
  expect_s3_class(res, "regional_mvpa_result")
  expect_true(is.data.frame(res$performance_table))
  # Check a couple of expected metrics exist
  expect_true(all(c("geom_cor", "era_top1_acc") %in% names(res$performance_table)))
})


test_that("era_rsa_model searchlight returns metric maps", {
  skip_on_cran()
  set.seed(456)

  toy <- gen_sample_dataset(D = c(4,4,4), nobs = 40, nlevels = 2, blocks = 2, external_test = TRUE)
  toy$design$train_design$item <- toy$design$train_design$Y
  toy$design$test_design$item  <- toy$design$test_design$Ytest

  ms <- era_rsa_model(
    dataset = toy$dataset,
    design  = toy$design,
    key_var = ~ item,
    phase_var = ~ block_var,
    distfun = cordist("pearson"),
    rsa_simfun = "pearson"
  )

  sl <- run_searchlight(ms, radius = 3, method = "standard")
  expect_s3_class(sl, "searchlight_result")
  # At least these metrics should be present as maps
  expect_true(all(c("geom_cor", "era_top1_acc") %in% sl$metrics))
})


test_that("era_rsa_model accepts confound RDMs and emits beta_* metrics", {
  skip_on_cran()
  set.seed(789)

  toy <- gen_sample_dataset(D = c(3,3,3), nobs = 36, nlevels = 3, blocks = 3, external_test = TRUE)
  toy$design$train_design$item <- toy$design$train_design$Y
  toy$design$test_design$item  <- toy$design$test_design$Ytest

  # Build a simple block-based confound RDM at the item level using training block_var
  item_levels <- levels(toy$design$train_design$item)
  # modal block per item (encoding phase)
  Mode <- function(x) { ux <- unique(x); ux[which.max(tabulate(match(x, ux)))] }
  enc_block_by_item <- sapply(item_levels, function(it) {
    Mode(toy$design$train_design$block_var[toy$design$train_design$item == it])
  })
  names(enc_block_by_item) <- item_levels
  block_rdm <- outer(enc_block_by_item, enc_block_by_item, FUN = function(a,b) as.numeric(a != b))
  rownames(block_rdm) <- colnames(block_rdm) <- item_levels

  ms <- era_rsa_model(
    dataset = toy$dataset,
    design  = toy$design,
    key_var = ~ item,
    phase_var = ~ block_var,
    confound_rdms = list(block = block_rdm)
  )

  regionMask <- neuroim2::NeuroVol(sample(1:2, size = length(toy$dataset$mask), replace = TRUE),
                                   neuroim2::space(toy$dataset$mask))
  res <- run_regional(ms, regionMask)
  expect_s3_class(res, "regional_mvpa_result")
  # Expect at least one beta_ term from geometry regression
  expect_true(any(grepl("^beta_", names(res$performance_table))))
})

