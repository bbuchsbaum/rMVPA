library(testthat)
library(rMVPA)

test_check("rMVPA")
