#' Naive Cross-Decoding (correlation to source prototypes)
#'
#' Baseline analysis that classifies target-domain trials by correlating them
#' directly with source-domain prototypes (means over repeats) without any
#' adaptation. Serves as a comparator for REMAP-RRR.
#'
#' @param dataset mvpa_dataset with train_data (source) and test_data (target)
#' @param design  mvpa_design with y_train/y_test and optional `link_by` column
#'   present in both train/test designs. If `link_by` is NULL, prototypes are
#'   formed by the training labels `y_train` and evaluated against `y_test`.
#' @param link_by Optional character; if provided, prototypes and observed labels
#'   are keyed by this column instead of y.
#' @param return_predictions logical; keep per-ROI predictions.
#'
#' @return model spec object of class `naive_xdec_model` for use with
#'   `run_regional()` or `run_searchlight()`.
#' @export
naive_xdec_model <- function(dataset, design, link_by = NULL, return_predictions = TRUE, ...) {
  # Choose performance function based on training response
  perf_fun <- if (is.numeric(design$y_train)) {
    get_regression_perf(design$split_groups)
  } else if (length(levels(design$y_train)) > 2) {
    get_multiclass_perf(design$split_groups, class_metrics = TRUE)
  } else {
    get_binary_perf(design$split_groups)
  }

  create_model_spec(
    "naive_xdec_model",
    dataset = dataset,
    design  = design,
    link_by = link_by,
    performance = perf_fun,
    compute_performance = TRUE,
    return_predictions = return_predictions,
    ...
  )
}

#' @keywords internal
.nx_rowsum_mean <- function(X, f) {
  f <- factor(f)
  rowsum(X, f, reorder = TRUE) / as.vector(table(f))
}

#' @keywords internal
.nx_softmax <- function(scores) {
  # numerically-stable row-wise softmax
  m <- apply(scores, 1, max)
  z <- exp(sweep(scores, 1, m, "-"))
  sweep(z, 1, rowSums(z), "/")
}

#' @export
compute_performance.naive_xdec_model <- function(obj, result) {
  obj$performance(result)
}

#' Naive cross-decoding per ROI
#' @keywords internal
#' @export
process_roi.naive_xdec_model <- function(mod_spec, roi, rnum, ...) {
  if (!has_test_set(mod_spec)) {
    return(tibble::tibble(
      result = list(NULL), indices = list(neuroim2::indices(roi$train_roi)),
      performance = list(NULL), id = rnum,
      error = TRUE, error_message = "naive_xdec_model requires external test set"
    ))
  }

  Xtr <- as.matrix(neuroim2::values(roi$train_roi))
  Xte <- as.matrix(neuroim2::values(roi$test_roi))
  des <- mod_spec$design

  # Keys for prototypes and observed labels
  if (!is.null(mod_spec$link_by) && mod_spec$link_by %in% colnames(des$train_design) && mod_spec$link_by %in% colnames(des$test_design)) {
    key_tr <- factor(des$train_design[[mod_spec$link_by]])
    key_te <- factor(des$test_design[[mod_spec$link_by]])
  } else {
    key_tr <- factor(des$y_train)
    key_te <- factor(des$y_test)
  }

  # Align on common keys and build prototypes
  Xp <- .nx_rowsum_mean(Xtr, key_tr)   # prototypes per key
  levs <- rownames(Xp)
  # Ensure observed uses same level set
  obs <- factor(as.character(key_te), levels = levs)

  # Correlate each test row to prototypes (columns = levs)
  # Use base cor for correctness; speed is adequate at ROI scale
  scores <- cor(t(Xte), t(Xp))
  if (is.null(colnames(scores))) colnames(scores) <- levs
  probs <- .nx_softmax(scores)
  colnames(probs) <- levs
  pred <- factor(levs[max.col(scores)], levels = levs)

  cres <- classification_result(obs, pred, probs,
                                testind = seq_len(nrow(Xte)),
                                test_design = des$test_design,
                                predictor = NULL)

  perf <- compute_performance(mod_spec, cres)
  tibble::tibble(
    result = list(cres),
    indices = list(neuroim2::indices(roi$train_roi)),
    performance = list(perf),
    id = rnum,
    error = FALSE,
    error_message = "~"
  )
}

